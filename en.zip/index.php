<?php
header( 'Location: pt/index.html' );